version = 'version :0.9.9.1'
botlog = '''
**2021年6月13日**
本次更新内容如下:
    - /up 自动更新，并重启程序
        - 首次使用需下载项目内config/bot.sh,并放置在容器config目录下
    - /set 新增代理设置，主要针对下载github，默认为"https://ghproxy.com"
        - 可自行修改，如不需要请修改为False
'''